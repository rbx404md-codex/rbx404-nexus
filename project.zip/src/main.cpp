#include <Arduino.h>
#include "version.h"
#include "storage_manager.h"
#include "wifi_manager.h"
#include "web_server.h"

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.printf("\nRBX404 NEXUS v%s (%s)\n", FW_VERSION, FW_BUILD_DATE);
  Storage::begin();
  WifiMgr::begin(Storage::config());
  Web::begin();
}

void loop() {
  WifiMgr::loop();
  Web::loop();
  delay(10);
}
