#include "storage_manager.h"
#include <Preferences.h>
#include "config.h"

static Preferences prefs;
static NetConfig cfg;

static String defaultApSsid() {
  uint64_t m = ESP.getEfuseMac();
  char b[24];
  snprintf(b, sizeof(b), "RBX404-NEXUS-%04X", (unsigned)((m >> 32) & 0xFFFF));
  return String(b);
}

static void load() {
  cfg.mode = prefs.getUChar("mode", MODE_AP);
  if (cfg.mode > MODE_APSTA) cfg.mode = MODE_AP;
  cfg.staSsid = prefs.getString("staSsid", "");
  cfg.staPass = prefs.getString("staPass", "");
  cfg.apSsid = prefs.getString("apSsid", defaultApSsid());
  cfg.apPass = prefs.getString("apPass", DEFAULT_AP_PASS);
  cfg.apChannel = prefs.getUChar("apCh", DEFAULT_AP_CHANNEL);
  cfg.adminPass = prefs.getString("adminPw", DEFAULT_ADMIN_PASS);
}

namespace Storage {
void begin() { prefs.begin("nexus", false); load(); }
NetConfig& config() { return cfg; }
bool save() {
  prefs.putUChar("mode", cfg.mode);
  prefs.putString("staSsid", cfg.staSsid);
  prefs.putString("staPass", cfg.staPass);
  prefs.putString("apSsid", cfg.apSsid);
  prefs.putString("apPass", cfg.apPass);
  prefs.putUChar("apCh", cfg.apChannel);
  prefs.putString("adminPw", cfg.adminPass);
  return true;
}
bool usingDefaults() {
  return cfg.adminPass == DEFAULT_ADMIN_PASS || cfg.apPass == DEFAULT_AP_PASS;
}
void factoryReset() { prefs.clear(); load(); }
}
