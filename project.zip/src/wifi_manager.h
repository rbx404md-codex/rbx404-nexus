#pragma once
#include <Arduino.h>
#include "storage_manager.h"
namespace WifiMgr {
void begin(NetConfig& c);
void loop();
String statusJson();
String scanJson();
}
