#pragma once
#include <Arduino.h>
struct NetConfig {
  uint8_t mode;
  String staSsid, staPass, apSsid, apPass;
  uint8_t apChannel;
  String adminPass;
};
namespace Storage {
void begin();
NetConfig& config();
bool save();
bool usingDefaults();
void factoryReset();
}
