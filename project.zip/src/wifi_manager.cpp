#include "wifi_manager.h"
#include <WiFi.h>
#include <ArduinoJson.h>
#include "config.h"
#include "version.h"

namespace WifiMgr {
static NetConfig* cfg = nullptr;
static uint32_t lastAttempt = 0, lastGood = 0, backoff = STA_BACKOFF_MIN_MS;
static volatile uint32_t staUpSince = 0, reconnects = 0;
static volatile uint8_t lastReason = 0;
static bool apRunning = false, fallback = false;

static bool wantSta() { return cfg->mode != MODE_AP && cfg->staSsid.length() > 0; }
static bool wantAp() { return cfg->mode != MODE_STA; }

static void startAp() {
  WiFi.softAP(cfg->apSsid.c_str(), cfg->apPass.c_str(), cfg->apChannel, 0, MAX_AP_CLIENTS);
  apRunning = true;
  Serial.printf("[wifi] AP '%s' up at %s\n", cfg->apSsid.c_str(), WiFi.softAPIP().toString().c_str());
}

static void staBegin() {
  WiFi.begin(cfg->staSsid.c_str(), cfg->staPass.length() ? cfg->staPass.c_str() : nullptr);
  lastAttempt = millis();
}

static const char* hint(uint8_t r) {
  switch (r) {
    case 0: return "";
    case 201: return "network not found";
    case 202: case 15: case 204: return "wrong password?";
    case 200: return "weak signal";
    case 203: case 205: return "connection failed";
    default: return "disconnected";
  }
}

void begin(NetConfig& c) {
  cfg = &c;
  lastGood = millis();
  WiFi.persistent(false);
  WiFi.setAutoReconnect(false);
  WiFi.setHostname("rbx404-nexus");
  WiFi.onEvent([](arduino_event_id_t e, arduino_event_info_t info) {
    switch (e) {
      case ARDUINO_EVENT_WIFI_STA_GOT_IP:
        staUpSince = millis();
        lastReason = 0;
        Serial.printf("[wifi] STA ip %s\n", WiFi.localIP().toString().c_str());
        break;
      case ARDUINO_EVENT_WIFI_STA_DISCONNECTED:
        lastReason = info.wifi_sta_disconnected.reason;
        Serial.printf("[wifi] STA disconnected, reason %u\n", (unsigned)lastReason);
        break;
      case ARDUINO_EVENT_WIFI_AP_STACONNECTED:
        Serial.println("[wifi] AP client joined");
        break;
      default: break;
    }
  });
  bool ap = wantAp(), sta = wantSta();
  if (!ap && !sta) { ap = true; fallback = true; }
  WiFi.mode(ap ? WIFI_AP_STA : WIFI_STA);
  if (ap) startAp();
  if (sta) staBegin();
}

void loop() {
  if (!cfg || !wantSta()) return;
  uint32_t now = millis();
  if (WiFi.status() == WL_CONNECTED) {
    backoff = STA_BACKOFF_MIN_MS;
    lastGood = now;
    return;
  }
  if (now - lastAttempt >= backoff) {
    reconnects++;
    WiFi.disconnect(false);
    staBegin();
    backoff = min<uint32_t>(backoff * 2, STA_BACKOFF_MAX_MS);
  }
  if (!apRunning && now - lastGood >= FALLBACK_AP_DELAY_MS) {
    Serial.println("[wifi] STA down, starting fallback AP");
    WiFi.mode(WIFI_AP_STA);
    startAp();
    fallback = true;
  }
}

String statusJson() {
  JsonDocument d;
  bool c = WiFi.status() == WL_CONNECTED;
  d["mode"] = cfg->mode;
  d["apActive"] = apRunning;
  d["apSsid"] = cfg->apSsid;
  d["apIp"] = WiFi.softAPIP().toString();
  d["clients"] = WiFi.softAPgetStationNum();
  d["staConnected"] = c;
  d["staSsid"] = cfg->staSsid;
  if (c) {
    d["ip"] = WiFi.localIP().toString();
    d["gateway"] = WiFi.gatewayIP().toString();
    d["dns"] = WiFi.dnsIP().toString();
    d["subnet"] = WiFi.subnetMask().toString();
    d["rssi"] = WiFi.RSSI();
    d["netUptime"] = (millis() - staUpSince) / 1000;
  } else {
    d["hint"] = hint(lastReason);
  }
  d["mac"] = WiFi.macAddress();
  d["reconnects"] = (uint32_t)reconnects;
  d["fallback"] = fallback;
  d["uptime"] = millis() / 1000;
  d["heap"] = ESP.getFreeHeap();
  d["flash"] = ESP.getFlashChipSize();
  d["fw"] = FW_VERSION;
  d["defaultCreds"] = Storage::usingDefaults();
  String o;
  serializeJson(d, o);
  return o;
}

String scanJson() {
  JsonDocument d;
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_FAILED) {
    WiFi.scanNetworks(true);
    d["scanning"] = true;
  } else if (n == WIFI_SCAN_RUNNING) {
    d["scanning"] = true;
  } else {
    d["scanning"] = false;
    JsonArray a = d["nets"].to<JsonArray>();
    for (int i = 0; i < n && i < 20; i++) {
      if (WiFi.SSID(i).length() == 0) continue;
      JsonObject o = a.add<JsonObject>();
      o["ssid"] = WiFi.SSID(i);
      o["rssi"] = WiFi.RSSI(i);
      o["enc"] = WiFi.encryptionType(i) != WIFI_AUTH_OPEN;
      o["ch"] = WiFi.channel(i);
    }
    WiFi.scanDelete();
  }
  String o;
  serializeJson(d, o);
  return o;
}
}
