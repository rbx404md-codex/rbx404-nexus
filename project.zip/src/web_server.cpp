#include "web_server.h"
#include <ESPAsyncWebServer.h>
#include "mbedtls/base64.h"
#include "config.h"
#include "storage_manager.h"
#include "wifi_manager.h"

static AsyncWebServer server(80);
static volatile bool restartPending = false;
static uint32_t restartAt = 0;

static const char INDEX_HTML[] PROGMEM = R"HTML(<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RBX404 NEXUS</title>
<style>
:root{--bg:#0a0a0b;--card:rgba(255,255,255,.05);--bd:rgba(255,40,70,.35);--red:#ff2846;--tx:#eee;--mut:#9a9aa3}
*{box-sizing:border-box}
body{margin:0 auto;max-width:720px;padding:16px;background:radial-gradient(circle at 20% 0,#2a0a12,var(--bg) 55%) fixed;color:var(--tx);font:15px system-ui,sans-serif}
h1{font-size:20px;letter-spacing:3px;color:var(--red);text-shadow:0 0 12px var(--red);margin:6px 0}
small{color:var(--mut)}
.card{background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:14px;margin:12px 0;backdrop-filter:blur(10px);box-shadow:0 0 14px rgba(255,40,70,.12)}
.row{display:flex;justify-content:space-between;gap:10px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.06)}
.row b{text-align:right;word-break:break-all}
input,select,button{width:100%;padding:10px;margin:5px 0;border-radius:10px;border:1px solid var(--bd);background:#141416;color:var(--tx);font:inherit}
button{background:var(--red);border:0;font-weight:600}
button.g{background:#222;border:1px solid var(--bd)}
.warn{border-color:#ffb020;color:#ffb020}
</style></head><body>
<h1>RBX404 NEXUS</h1><small>CONTROL YOUR NETWORK. OWN YOUR SYSTEM.</small>
<div id="warn" class="card warn" hidden>Default passwords are still in use. Change them below.</div>
<div class="card"><div id="st">Loading...</div></div>
<div class="card"><button class="g" id="scanBtn" type="button">Scan Wi-Fi networks</button><div id="nets"></div></div>
<form id="f" class="card">
<label>Mode</label><select name="mode" id="mode"><option value="0">Access Point only</option><option value="1">Station (join router)</option><option value="2">AP + Station</option></select>
<label>Router SSID</label><input name="ssid" id="ssid" maxlength="32" autocomplete="off">
<label>Router password</label><input name="staPass" type="password" maxlength="63" placeholder="leave empty to keep">
<label>Hotspot name</label><input name="apSsid" id="apSsid" maxlength="32">
<label>Hotspot password (8+)</label><input name="apPass" type="password" maxlength="63" placeholder="leave empty to keep">
<label>Admin password (8+)</label><input name="adminPass" type="password" maxlength="32" placeholder="leave empty to keep">
<button type="submit">Save and restart</button><div id="msg"></div></form>
<button class="g" id="rb" type="button">Restart device</button>
<script>
const $=id=>document.getElementById(id);let inited=false;
async function status(){try{
const s=await (await fetch('/api/status')).json();
const rows=[['Mode',['AP','STA','AP+STA'][s.mode]],
['Hotspot',s.apActive?s.apSsid+' | '+s.apIp+' | '+s.clients+' clients':'off'],
['Router',s.staConnected?s.staSsid+' | '+s.ip+' | '+s.rssi+' dBm':'disconnected'+(s.hint?' ('+s.hint+')':'')],
['Gateway / DNS',s.staConnected?s.gateway+' / '+s.dns:'-'],
['Net uptime',s.staConnected?s.netUptime+' s':'-'],
['Reconnects',s.reconnects],['Uptime',s.uptime+' s'],['Free heap',s.heap+' B'],
['Flash',(s.flash/1048576)+' MB'],['Firmware',s.fw]];
const t=$('st');t.textContent='';
rows.forEach(r=>{const d=document.createElement('div');d.className='row';const a=document.createElement('span');a.textContent=r[0];const b=document.createElement('b');b.textContent=r[1];d.append(a,b);t.append(d);});
$('warn').hidden=!s.defaultCreds;
if(!inited){inited=true;$('mode').value=s.mode;$('ssid').value=s.staSsid;$('apSsid').value=s.apSsid;}
}catch(e){}}
async function scan(){
$('scanBtn').disabled=true;$('nets').textContent='Scanning...';
for(let i=0;i<12;i++){
const r=await (await fetch('/api/scan')).json();
if(!r.scanning){const n=$('nets');n.textContent='';
(r.nets||[]).forEach(x=>{const b=document.createElement('button');b.type='button';b.className='g';b.textContent=x.ssid+'  '+x.rssi+' dBm'+(x.enc?' (locked)':'');b.onclick=()=>{$('ssid').value=x.ssid;};n.append(b);});
if(!(r.nets||[]).length)n.textContent='No networks found';break;}
await new Promise(k=>setTimeout(k,1000));}
$('scanBtn').disabled=false;}
$('scanBtn').onclick=scan;
$('f').onsubmit=async e=>{e.preventDefault();
const r=await fetch('/api/wifi',{method:'POST',body:new URLSearchParams(new FormData($('f')))});
const j=await r.json();$('msg').textContent=j.ok?j.msg:j.error;};
$('rb').onclick=async()=>{if(confirm('Restart now?')){await fetch('/api/reboot',{method:'POST'});$('msg').textContent='Restarting...';}};
status();setInterval(status,3000);
</script></body></html>)HTML";

static bool authed(AsyncWebServerRequest* r) {
  if (!r->hasHeader("Authorization")) return false;
  String raw = String(ADMIN_USER) + ":" + Storage::config().adminPass;
  unsigned char buf[160];
  size_t olen = 0;
  if (mbedtls_base64_encode(buf, sizeof(buf) - 1, &olen, (const unsigned char*)raw.c_str(), raw.length()) != 0) return false;
  buf[olen] = 0;
  String expected = String("Basic ") + (const char*)buf;
  String got = r->header("Authorization");
  if (got.length() != expected.length()) return false;
  uint8_t diff = 0;
  for (size_t i = 0; i < got.length(); i++) diff |= (uint8_t)(got[i] ^ expected[i]);
  return diff == 0;
}

static void deny(AsyncWebServerRequest* r) {
  AsyncWebServerResponse* res = r->beginResponse(401, "text/plain", "Authentication required");
  res->addHeader("WWW-Authenticate", "Basic realm=\"RBX404 NEXUS\"");
  r->send(res);
}

#define REQUIRE_AUTH(r) if (!authed(r)) { deny(r); return; }

static void reply(AsyncWebServerRequest* r, int code, bool ok, const String& text) {
  String j = String("{\"ok\":") + (ok ? "true" : "false") + ",\"" + (ok ? "msg" : "error") + "\":\"" + text + "\"}";
  r->send(code, "application/json", j);
}

static String param(AsyncWebServerRequest* r, const char* n) {
  if (!r->hasParam(n, true)) return String();
  return r->getParam(n, true)->value();
}

namespace Web {
void begin() {
  server.on("/", HTTP_GET, [](AsyncWebServerRequest* r) {
    REQUIRE_AUTH(r);
    r->send_P(200, "text/html", INDEX_HTML);
  });
  server.on("/api/status", HTTP_GET, [](AsyncWebServerRequest* r) {
    REQUIRE_AUTH(r);
    r->send(200, "application/json", WifiMgr::statusJson());
  });
  server.on("/api/scan", HTTP_GET, [](AsyncWebServerRequest* r) {
    REQUIRE_AUTH(r);
    r->send(200, "application/json", WifiMgr::scanJson());
  });
  server.on("/api/reboot", HTTP_POST, [](AsyncWebServerRequest* r) {
    REQUIRE_AUTH(r);
    reply(r, 200, true, "Restarting");
    restartPending = true;
    restartAt = millis() + 800;
  });
  server.on("/api/wifi", HTTP_POST, [](AsyncWebServerRequest* r) {
    REQUIRE_AUTH(r);
    NetConfig& c = Storage::config();
    String modeS = param(r, "mode"), ssid = param(r, "ssid"), staPass = param(r, "staPass");
    String apSsid = param(r, "apSsid"), apPass = param(r, "apPass"), adminPass = param(r, "adminPass");
    if (modeS.length() != 1 || modeS[0] < '0' || modeS[0] > '2') return reply(r, 400, false, "Invalid mode");
    uint8_t mode = modeS[0] - '0';
    if (ssid.length() > 32) return reply(r, 400, false, "Router SSID too long");
    if (mode != MODE_AP && ssid.length() == 0) return reply(r, 400, false, "Router SSID required for this mode");
    if (staPass.length() > 63 || (staPass.length() > 0 && staPass.length() < 8)) return reply(r, 400, false, "Router password must be 8-63 characters");
    if (apSsid.length() < 1 || apSsid.length() > 32) return reply(r, 400, false, "Hotspot name must be 1-32 characters");
    if (apPass.length() > 0 && (apPass.length() < 8 || apPass.length() > 63)) return reply(r, 400, false, "Hotspot password must be 8-63 characters");
    if (adminPass.length() > 0 && (adminPass.length() < 8 || adminPass.length() > 32)) return reply(r, 400, false, "Admin password must be 8-32 characters");
    if (ssid != c.staSsid && staPass.length() == 0) c.staPass = "";
    else if (staPass.length() > 0) c.staPass = staPass;
    c.mode = mode;
    c.staSsid = ssid;
    c.apSsid = apSsid;
    if (apPass.length() > 0) c.apPass = apPass;
    if (adminPass.length() > 0) c.adminPass = adminPass;
    Storage::save();
    reply(r, 200, true, "Saved. Restarting - reconnect to the new network.");
    restartPending = true;
    restartAt = millis() + 1500;
  });
  server.onNotFound([](AsyncWebServerRequest* r) { r->send(404, "text/plain", "Not found"); });
  server.begin();
}
void loop() {
  if (restartPending && (int32_t)(millis() - restartAt) >= 0) ESP.restart();
}
}
