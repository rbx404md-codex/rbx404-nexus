# Changelog
## 0.2.0 - Phase 1+2
- Architecture, partition table (4MB, dual OTA slots), PlatformIO config
- Wi-Fi manager: AP / STA / AP+STA, backoff reconnect, fallback AP, diagnostics hints, scan
- Interim admin page with HTTP Basic auth (replaced in Phase 4 by sessions + CSRF)
- NOT yet compiled or tested on hardware
