# RBX404 NEXUS (Phase 2)
Default hotspot: SSID RBX404-NEXUS-XXXX, password `rbx404nexus`
Open http://192.168.4.1  -> login: admin / admin404nexus
Change all passwords on first login.
Status: untested source. Build with GitHub Actions (see .github/workflows/build.yml).
