#pragma once
#define FW_VERSION "0.2.0"
#define FW_BUILD_DATE __DATE__ " " __TIME__
