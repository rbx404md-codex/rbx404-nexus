#pragma once
#define ADMIN_USER "admin"
#define DEFAULT_ADMIN_PASS "admin404nexus"
#define DEFAULT_AP_PASS "rbx404nexus"
#define DEFAULT_AP_CHANNEL 6
#define MAX_AP_CLIENTS 4
#define FALLBACK_AP_DELAY_MS 30000UL
#define STA_BACKOFF_MIN_MS 5000UL
#define STA_BACKOFF_MAX_MS 60000UL
#define MODE_AP 0
#define MODE_STA 1
#define MODE_APSTA 2
