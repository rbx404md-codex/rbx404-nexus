#!/bin/sh
pio run && ls -l .pio/build/esp32dev/*.bin
